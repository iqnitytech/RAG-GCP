"""Single source of truth for the SDK version (semantic versioning)."""

__version__ = "0.1.0"

